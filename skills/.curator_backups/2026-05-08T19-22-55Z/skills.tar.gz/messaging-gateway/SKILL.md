---
name: messaging-gateway
description: Managing messaging platforms (WhatsApp, Telegram, Discord), home channels, and connection troubleshooting.
---

# Messaging Gateway

This skill manages messaging platform configurations and troubleshooting for Hermes Agent.

### Proactive Messaging Policy
- **User Preference**: Zhafif prefers concise, direct responses without conversational filler. When delivering output, avoid meta-explanations ("I am checking," "I will do this") if the action is already completed.
- **Workflow Update**: For WhatsApp, always prioritize informing the user about the "existing chat history" requirement immediately. If the user insists on proactive messaging to a new number, pivot to discussing Business API (Fonnte/Twilio) integration, as standard bridges cannot bypass this limitation.
- **Home Channel Configuration**: When setting `HOME_CHANNEL` (e.g., `WHATSAPP_HOME_CHANNEL`) in `config.yaml` via `hermes config set`, the change might not take effect immediately due to internal caching. If errors persist, try specifying the target ID directly in the `send_message` call or restarting the agent.
- **Platform-Specific Targeting**: Always verify target availability using `send_message(action='list')` before sending. If a platform is listed but fails on "home channel" requirements, pass the full ID (e.g., `whatsapp:70729588568201@lid`).

## References
- [WhatsApp Troubleshooting](references/whatsapp-troubleshooting.md): Documentation on common bridge errors like `jidDecode`.
